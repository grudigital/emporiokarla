
<!-- jQuery  -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/modernizr.min.js"></script>
<script src="assets/js/jquery.slimscroll.js"></script>
<script src="assets/js/waves.js"></script>
<script src="assets/js/jquery.nicescroll.js"></script>
<script src="assets/js/jquery.scrollTo.min.js"></script>

<!--<script type="text/javascript" src="assets/js/jquery.js"></script>-->
<script type="text/javascript" src="assets/js/jquery-ui.min.js"></script>

<!-- Peity chart JS -->
<script src="../plugins/peity-chart/jquery.peity.min.js"></script>

<!--C3 Chart-->
<script src="../plugins/d3/d3.min.js"></script>
<script src="../plugins/c3/c3.min.js"></script>

<!-- KNOB JS -->
<script src="../plugins/jquery-knob/excanvas.js"></script>
<script src="../plugins/jquery-knob/jquery.knob.js"></script>

<!-- Page specific js -->
<script src="assets/pages/dashboard.js"></script>

<!-- App js -->
<script src="assets/js/app.js"></script>

<script src="../plugins/dropzone/dist/dropzone.js"></script>

<!--Mascara de preço-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-maskmoney/3.0.2/jquery.maskMoney.min.js"></script>